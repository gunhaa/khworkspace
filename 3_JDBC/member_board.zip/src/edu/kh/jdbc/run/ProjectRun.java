package edu.kh.jdbc.run;

import edu.kh.jdbc.main.view.MainView;

public class ProjectRun {

	public static void main(String[] args) {
		MainView view = new MainView();
		view.displayMenu();
	}
	
}
