package edu.kh.jdbc.board.model.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import edu.kh.jdbc.board.model.vo.Board;
import static edu.kh.jdbc.common.JDBCTemplate.getConnection;
import static edu.kh.jdbc.common.JDBCTemplate.close;
import static edu.kh.jdbc.common.JDBCTemplate.commit;
import static edu.kh.jdbc.common.JDBCTemplate.rollback;
import edu.kh.jdbc.common.JDBCTemplate;

public class BoardDAO {

	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private Properties prop = new Properties();
	// Map인데 k,v가 모두 String , 외부 XML파일 입출력 특화

	//memberDao 기본 생성자
	public BoardDAO() {
		//MemberDAO객체 생성시
		//member-sql.xml파일의 내용을 읽어와서 
		//properties 객체 생성

		try {
			prop = new Properties();
			prop.loadFromXML(new FileInputStream("board-sql.xml"));
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

	
	
	public List<Board> selectAll(Connection conn) throws Exception {

		List<Board> boardList = new ArrayList<>();		

		try {
			
			//1) sql 작성
			String sql = prop.getProperty("selectAll");
			//2) statement 생성
			stmt = conn.createStatement();
			//3) sql 수행 후 결과 반환 받기
			rs = stmt.executeQuery(sql);
			//4) ResultSet에 한 행씩 접근
			while(rs.next()) {
				// 5) 해당 행에서 컬럼명을 이용해 컬럼 값 얻어오기
				int board_no = rs.getInt("BOARD_NO");
				String board_title = rs.getString("BOARD_TITLE");
				Date create_date = rs.getDate("CREATE_DATE");
				int read_count = rs.getInt("READ_COUNT");
				String member_nm = rs.getString("MEMBER_NM");
				int reply_count = rs.getInt("REPLY_COUNT");
				// 6) Board 객체를 생성하여 컬럼 값 담기
				Board board = new Board(board_no, board_title, create_date, read_count, member_nm,reply_count);
				// 7) Board 객체를 boardList에 추가
				boardList.add(board);

			}
			
			
		} finally {
			close(rs);
			close(stmt);
		}
		




		return boardList;
	}

}
