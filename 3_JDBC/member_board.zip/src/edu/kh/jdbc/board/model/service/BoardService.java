package edu.kh.jdbc.board.model.service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import edu.kh.jdbc.board.model.dao.BoardDAO;
import edu.kh.jdbc.board.model.vo.Board;

// import static : static 필드 / 메소드 호출 시 클래스명 생략
import static edu.kh.jdbc.common.JDBCTemplate.getConnection;
import static edu.kh.jdbc.common.JDBCTemplate.close;
import static edu.kh.jdbc.common.JDBCTemplate.commit;
import static edu.kh.jdbc.common.JDBCTemplate.rollback;
import edu.kh.jdbc.common.JDBCTemplate;
// * 기호 : 모두, 전부(ALL)


public class BoardService {

	BoardDAO dao = new BoardDAO();
	
	
	/** 게시글 목록 조회 Service
	 * @return boardList
	 * @throws Exception
	 */
	public List<Board> selectAll() throws Exception {
		
		List<Board> boardList = new ArrayList<>();		
		// 1) Connection 생성
		Connection conn = getConnection();
		// 2) DAO 메소드 (SELECT) 호출 후 결과 반환 받고
		boardList = dao.selectAll(conn);
		// 3)Connetction 반환
		close(conn);
		// 4) DAO 수행 결과 View에 반환
		return boardList;
	}

}
