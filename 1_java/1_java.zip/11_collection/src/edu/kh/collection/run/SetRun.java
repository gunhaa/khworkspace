package edu.kh.collection.run;

import edu.kh.collection.model.service.SetService;

public class SetRun {
	public static void main(String[] args) {
		SetService service  = new SetService();
		service.lotto();
	}
}
