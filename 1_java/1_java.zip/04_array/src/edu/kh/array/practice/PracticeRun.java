package edu.kh.array.practice;

public class PracticeRun {

	public static void main(String[] args) {
		ArrayPractice arrPr = new ArrayPractice();
		arrPr.practice14();
	}
}
