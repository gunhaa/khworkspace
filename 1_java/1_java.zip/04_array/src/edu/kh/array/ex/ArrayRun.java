package edu.kh.array.ex;

public class ArrayRun {
	public static void main(String[] args) {
		
		//ArrayExample1 arrEx = new ArrayExample1();
		//arrEx.ex9();

		ArrayExample2 arrEx2 = new ArrayExample2();
		arrEx2.createLottoNumber();
	}
}
