package edu.kh.poly.ex1.run;

import edu.kh.poly.ex1.model.service.PolyService;

public class PolyRun {
	public static void main(String[] args) {

		PolyService Service = new PolyService();

		Service.ex5();
	}
}
