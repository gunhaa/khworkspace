package edu.kh.poly.ex2.model.service;

public interface Calculator {


	//계산기 인터페이스
	// -> 모든 계산기에 대한 공통 필드, 기능명을 제공하는 접점(interface) 용도


	// 인터페이스 : 추상 클래스의 변형체 (추상 클래스 보다 추상도 높음)
	// - 추상 클래스 : 일부만 추상 메소드(0개 이상)
	// - 인터 페이스 : 모두 추상 메소드

	//필드 (묵시적으로 public static final)
	// -> 어떻게 작성하든 모두 public static final
	public static final double PI = 3.14;

	static final int MAX_NUM = 10000;

	public int MIN_NUM = -10000;

	int ZERO = 0;
	//모두 public static final 이 들어가 있음.

	//메소드 (묵시적으로 public abstract)
	public abstract int plus(int num1 , int num2);

	public abstract int minus(int num1 , int num2);

	public abstract int multiple(int num1 , int num2);

	public abstract int divide(int num1 , int num2);




}

