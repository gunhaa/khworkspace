package edu_kh_op.ex;

public class ExampleRun { //코드 실행용 클래스

	public static void main(String[] args) {

		
		// OpExample 생성
		OpExample ex = new OpExample();
		//ex.ex1(); // ex가 가지고 있는 ex1() 메소드 실행
		//ex.ex2();
		//ex.ex3();
		//ex.ex4();
		//ex.ex5();
		//ex.ex6();
		//ex.ex7();
		ex.ex8();
	}
	
}
