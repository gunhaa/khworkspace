package edu.kh.op.practice;

public class PracticeRun {

	public static void main(String[] args) {
		
		OpPractice pr = new OpPractice();
		
		//pr.practice1();
		//pr.practice2();
		//pr.practice3();
		pr.practice4();
	}
	
}