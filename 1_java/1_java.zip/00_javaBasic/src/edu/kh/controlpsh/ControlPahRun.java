package edu.kh.controlpsh;

public class ControlPahRun {

	public static void main(String[] args) {
		
		ControlPsh co = new ControlPsh();
		//co.ex1();
		//co.ex2();
		//co.ex3();
		co.ex4();
		
		
		
		
	}
	
}
