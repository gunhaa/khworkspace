package edu.kh.psh;

public class PshRun1 {

	public static void main(String[] args) {
		
		PshEx ex = new PshEx();
		//ex.exam1();
		ex.exam4();
		
		
	}
	
}
