package condition;

public class ConditionRun {

	public static void main(String[] args) {
		
		ConditionExample condition = new ConditionExample();
		
		//condition.ex1();
		//condition.ex2();
		//condition.ex3();
		//condition.ex4();
		//condition.ex5();
		//condition.ex6();
		//condition.ex7();
		//condition.ex8();
		SwitchExample switchEx = new SwitchExample();
		//자료형	       이름
		//switchEx.ex1();		
		//switchEx.ex2();
		//switchEx.ex3();
		switchEx.ex4();
		
	}
	
}
