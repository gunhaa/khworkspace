package condition;

public class BranchRun {

	public static void main(String[] args) {
		
		BranchExample BranchEx = new BranchExample();
		BranchEx.RPSGame();
		
		
	}
	
}
