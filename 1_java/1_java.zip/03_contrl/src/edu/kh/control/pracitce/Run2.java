package edu.kh.control.pracitce;

public class Run2 {

	public static void main(String[] args) {
		
		LoopPractice Run = new LoopPractice ();

		Run.practice13();

	}
}
