package edu.kh.control.pracitce;

public class Run1 {

	public static void main(String[] args) {
		
		ConditionPractice Run = new ConditionPractice();
		
		Run.practice5();
		
	}
	
}