package edu.kh.control.loop;

public class LoopRun {

	//메인 메소드 자동 완성
	//main ctrl
	
	public static void main(String[] args) {
		
		//ForExample forEx = new ForExample();
		//forEx.ex21();
		
		WhileExample whileEx = new WhileExample();
		whileEx.ex2();
		
	}
	
}
