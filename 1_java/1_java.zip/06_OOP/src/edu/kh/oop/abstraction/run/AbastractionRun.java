package edu.kh.oop.abstraction.run;

import edu.kh.oop.abstraction.model.service.AbstractionService;

public class AbastractionRun {

	public static void main(String[] args) {

		AbstractionService as = new AbstractionService();
		
		as.ex1();
		
	}	

}
