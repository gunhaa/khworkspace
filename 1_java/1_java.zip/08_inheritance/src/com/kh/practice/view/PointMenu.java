package com.kh.practice.view;

public class PointMenu {

}
