package edu.kh.inheritance.run;

import edu.kh.inheritance.model.service.inheritanceService;
import edu.kh.inheritance.model.vo.Parent;

public class inheritanceRun {
	public static void main(String[] args) {

		inheritanceService Service = new inheritanceService();
		
		Service.ex6();
		
	}
}
