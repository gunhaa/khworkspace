package edu.kh.inheritance.model.vo;

public final class Parent { //부모 클래스
	//Object 상속 중
	
	// ** final 클래스 **
	// -> 마지막 클래스라는 의미로 
	//    "더 이상 상속 불가"를 의미한다.
	
	public final void method() {
		System.out.println("테스트용 메소드");
	}
	
	
}
