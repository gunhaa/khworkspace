package edu.kh.inheritance.model.vo;

public class Child /*extends Parent*/ { //자식 클래스
	// Parent 상속 중
	// The type Child cannot subclass the final class Parent
	// (fianl 클래스인 Parent는 child클래스를 자식으로 가질 수 없다.)
/*
	@Override
	public void method() {
		System.out.println("오버라이딩");
	}
*/ //봐야할때 활성화시키기	
	//Cannot override
	//the final method form Parent
}
