package edu.kh.inheritance.practice.run;

import edu.kh.inheritance.practice.model.service.PracticeService;

public class PracticeRun {
	public static void main(String[] args) {
		PracticeService Service= new PracticeService();

		Service.homework();
	}
}
