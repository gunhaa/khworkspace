package edu.kh.array2.practice;

public class PracticeRun {

	public static void main(String[] args) {

		Array2Practice arr2Pr = new Array2Practice();
		
		
		arr2Pr.bingoGame_1();
	}
}
