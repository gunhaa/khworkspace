package edu.kh.array2.ex;

public class Array2Run {

	public static void main(String[] args) {
	
		Array2Example arr2Ex = new Array2Example();
		
		
		arr2Ex.ex3();
	}
	
	
	
}
