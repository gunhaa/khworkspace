package edu.kh.oarr.practice.run;

import edu.kh.oarr.practice.model.service.EmployeeService;

public class PracticeRun {
	public static void main(String[] args) {

		EmployeeService emp = new EmployeeService();
		
		emp.run1();
	}
}
