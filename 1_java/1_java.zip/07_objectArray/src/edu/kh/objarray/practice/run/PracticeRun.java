package edu.kh.objarray.practice.run;

import edu.kh.objarray.practice.model.service.PracticeService;

public class PracticeRun {
	public static void main(String[] args) {
		
		PracticeService Serv = new PracticeService();
		
		Serv.start();
		
	}
}
