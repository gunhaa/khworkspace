package edu.kh.exception.run;

import edu.kh.exception.model.service.ExceptionService;

public class ExceptionRun {

	public static void main(String[] args) {
		
		ExceptionService serv=new ExceptionService();
		
		
		serv.ex5();
		
	}
	
}
