// // 소분류 버튼 리스너
// (function(){
//   const subCategoryBtn = document.getElementsByClassName("subCategoryBtn");
  



//   for(let subCate of subCategoryBtn){
//     subCate.addEventListener("click", function(event){
//         // 현재 URL 가져오기
//         const currentUrl = window.location.href;

//         // URL을 '/'로 분리하여 배열로 만듦
//         const urlParts = currentUrl.split('/');
//       alert(currentUrl + urlParts);
//     })
  
//   }
// })();



  